-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: gcash_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `gcash_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `gcash_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `gcash_db`;

--
-- Table structure for table `tbl_record`
--

DROP TABLE IF EXISTS `tbl_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_record` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `refer` bigint(200) NOT NULL,
  `no` bigint(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `amount` int(50) NOT NULL,
  `charge` int(50) NOT NULL,
  `type` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_record`
--

LOCK TABLES `tbl_record` WRITE;
/*!40000 ALTER TABLE `tbl_record` DISABLE KEYS */;
INSERT INTO `tbl_record` VALUES (1,'jasper',3263232323,9628463726,'Casiguran','2025-05-28 17:07:09',1000,10,'cashin'),(3,'pekong',127786467,9567685024,'Bianoan,Casiguran,Aurora','2025-05-30 14:03:09',8000,80,'cashin'),(7,'jasper',3243243243423,95607368534,'Ezteves, Casiguran, Aurora','2025-05-30 14:04:39',1000,10,'cashin'),(17,'jmie',4932424,324010279,'Brgy,bianoan,','2025-05-30 14:04:31',2333,30,'cashin'),(21,'jasper',34893632823,9328332,'sidihaihdlsa','2025-05-30 14:04:51',344,10,'cashin'),(23,'jasper',34941834,934313413,'bianoan','2025-05-30 14:05:02',10000,100,'cashin'),(25,'jmie',3029473274,9560736850,'ibonaaaa','2025-05-30 14:04:20',10000,100,'cashin'),(27,'sean',987655,912345678,'Brgy 4, MAA','2025-05-30 02:47:54',10000,100,'cashout'),(28,'jmie',123456789,998765432,'Brgy 1, MAA','2025-05-30 14:04:10',2000,20,'cashin'),(29,'jmie',45676767,9124567891,'Brgy. 3, Maria Aurora, Aurora','2025-05-30 14:04:02',7520,80,'cashin'),(30,'sean',1234467987,98765432100,'Esteves, Casiguran','2025-05-30 14:03:42',9848,100,'cashin'),(31,'sean',1234567,9123456,'Brgy 3, MAA','2025-05-30 14:03:51',1234,20,'cashin'),(32,'pekong',23443234,34234,'dfslhfas','2025-05-30 14:03:22',9578,100,'cashin'),(33,'pekong',23907234,3423434,';asdsak,asd','2025-05-30 14:03:33',3424,40,'cashin'),(34,'sean',543445,2348794234,'bianoan casiguran aurora','2025-05-30 14:01:49',5000,50,'cashin'),(35,'sean',3894236436943,3482434234,'zabali','2025-05-30 14:02:18',7000,70,'cashin'),(36,'jasper',939247234,9560736850,'bianoan ','2025-05-30 14:24:53',900,10,'cashin'),(37,'jasper',95607368503434,9560736850,'Bianoan, Casiguran, Aurora','2025-05-31 02:40:38',7000,70,'cashin'),(38,'jasper',99333023332112,9560736850,'Bianoan, Casiguran, Aurora','2025-05-31 02:41:59',5999,60,'cashout');
/*!40000 ALTER TABLE `tbl_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` VALUES (1,'pekong','1234'),(2,'jasper','1234'),(3,'jmie','4567'),(4,'jmie','1234'),(5,'jmie','56789'),(6,'Jasper Karl','12345');
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-31 10:53:45
